
<?php 	
	require_once "../controlador/Conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();
			$sql="SELECT nombre, email, sexo, area_id, boletin from empleados";				
	$result=mysqli_query($conexion,$sql);
 ?>


<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
<thead>
    <tr>
		<th><span class="fas fa-user"></span>Nombre</th>
		<th><span class="fas fa-at"></span>Email</th>
		<th><span class="fas fa-venus-mars"></span>Sexo</th>
		<th><span class="fas fa-briefcase"></span>Area</th>
		<th><span class="fas fa-envelope"></span>Boletin</th>        
		<th>Modificar</th>		
		<th>Eliminar</th>
	</tr>
</thead>
	<?php while($ver=mysqli_fetch_row($result)): ?>
<tbody>	
        <tr>
		<td><?php echo $ver[0]; ?></td>
		<td><?php echo $ver[1]; ?></td>
		<td><?php echo $ver[2]; ?></td>
		<td><?php echo $ver[3]; ?></td>
		<td><?php echo $ver[4]; ?></td>
		<td>
            <span data-toggle="modal" data-target="#actualizaUsuarioModal" onclick="agregaDatosUsuario('<?php echo $ver[0]; ?>')">
					<span class="fas fa-edit"></span>
			</span>
		</td>
      
		<td>
			<span  onclick="eliminarUsuario('<?php echo $ver[0]; ?>')">
				<span class="fas fa-trash-alt"></span>
			</span>
		</td>
	</tr>
<?php endwhile; ?>
    </tbody>
</table>