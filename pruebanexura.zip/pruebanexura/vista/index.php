<?php
    require_once "../controlador/Conexion.php";
	$obj= new conectar();
	$mysqli= $obj->conexion();   
?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">    
    <link rel="stylesheet" type="text/css" href="../librerias/alertifyjs/css/alertify.css">
    <link rel="stylesheet" type="text/css" href="../librerias/alertifyjs/css/themes/default.css">
    <link rel="stylesheet" type="text/css" href="../librerias/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../librerias/select2/css/select2.css">
    <link rel="stylesheet" type="text/css" href="../css/menu.css">

                

    <script src="../librerias/jquery-3.2.1.min.js"></script>
    <script src="../librerias/alertifyjs/alertify.js"></script>
    <script src="../librerias/bootstrap/js/bootstrap.js"></script>
    <script src="../librerias/select2/js/select2.js"></script>
    <script src="../js/funciones.js"></script>
    <script src="../librerias/sweetalert.min.js"></script>    
    <script src="icons/js/all.js"></script>    


    <title>Empleados</title>
</head>
<body>
 	<br />
   <br />
   <br />
    <div class="container">				
        <h1>Crear empleado</h1>
        <p style="color:cadetblue;background-color:lightcyan;border-color:#000;border-top-color:#337ab7;padding:20px;border-radius:5px;">Los campos con (*) son obligatorios</p>
        <!--<form id="frmempleado" name="frmempleado" style="width:100%;" method="post" action="../controlador/insertarempleado.php">-->
        <form id="frmempleado" name="frmempleado" style="width:100%;">
            <div class="form-group">
                <label class="formulario-label" for="nombre">Nombre completo *</label> <input type="text" class="form-control formulario-input" placeholder="Nombre completo del empleado" name="nombre" id="nombre">
            </div>					
            <br />
            <br />
            <br />
            <br />
            <div class="form-group">
                <label class="formulario-label" for="email">Correo electr&oacute;nico *</label> <input type="text" class="form-control formulario-input" placeholder="Correo electr&oacute;nico" name="email" id="email">
            </div>		
            <br />
            <br />
            <br />
            <br />
            <div class="form-group">		
                <label class="formulario__label">Sexo *</label>
                <div style="float:right;width:87%;">
                    <input type="radio" id="sexo" name="sexo" value="Masculino"><label>Masculino</label><br>
                    <input type="radio" id="sexo" name="sexo" value="Femenino"><label>Femenino</label><br>
                </div>		
            </div>		
            <br />
            <br />
            <div class="form-group">													
                <label class="formulario-label" for="area">&Aacute;rea *</label>
                <select class="form-control formulario-input" id="area" name="area">
                    <option value="">Selecciona el &aacute;rea</option>
                    <?php													
                        $query =$mysqli -> query("SELECT * from areas");
                        while($valores = mysqli_fetch_array($query))
                        {
                            echo '<option value="'.$valores[id].'">'.$valores[nombre].'</option>';
                        }
                    ?>                                   
                </select>
            </div>
            <br />
            <br />
            <div class="form-group">
                <label class="formulario-label" for="descripcion">Descripci&oacute;n *</label> 
                <textarea  class="form-control formulario-textarea" name="descripcion" id="descripcion"  placeholder="Descripci&oacute;n de la experiencia del empleado"></textarea>
                <br/>
                <br/>
                <br/>
                <br/>
                <input type="checkbox" id="boletin" name="boletin" value="1">
                <label for="boletin">Deseo recibir boletin informativo</label><br>

            </div>		
            <br/>
            <br/>
            <div class="form-group">
                <label class="formulario-label" for="roles">Roles *</label> 
                <div style="float:right;width:87%;">
                    <input type="checkbox" id="rol1" name="rol1" value="1">
                    <label for="rol1">Profesional de proyectos - desarrollador</label><br>
                    <input type="checkbox" id="rol2" name="rol2" value="2">
                    <label for="rol2">Gerente estrat&eacute;gico</label><br>
                    <input type="checkbox" id="rol3" name="rol3" value="3">
                    <label for="rol3">Auxiliar administrativo</label><br>      
                        <?php
                            /*
                            $SQL=$mysqli->query("SELECT * FROM roles");
                            while ($row =$SQL->fetch_array())
                            {
                                echo "<input type=\"checkbox\" name=\"seleccion[]\" id =\"roles\"  value=\"".$row['id']."\">".$row['nombre']."<br>";
                            }
                            */
                        ?>
                </div>		
            </div>		          
            <br/>
            <br/>
            <br/>
            <br/>
            <span class="btn btn-primary" id="guardar" name="guardar">Guardar empleado</span>
        </form>
        <br/>
        <br/>
        <h1>Lista de empleados</h1>
            <span data-toggle="modal"  class="btn btn-primary">
					<span class="fas fa-user-plus"></span>Crear
			</span>
        <div>
					<div id="tablaUsuariosLoad"></div>
		</div>
   </div>

		<!-- Button trigger modal -->
		<!-- Modal
		<div class="modal fade" id="actualizaUsuarioModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualiza Empleado</h4>
					</div>
					<div class="modal-body">
						<form id="frmRegistroU">
							<input type="text" hidden="" id="idUsuario" name="idUsuario">
							<label>Nombre</label>
							<input type="text" class="form-control input-sm" name="nombreU" id="nombreU">
							<label>Apellido</label>
							<input type="text" class="form-control input-sm" name="apellidoU" id="apellidoU">
							<label>Usuario</label>
							<input type="text" class="form-control input-sm" name="usuarioU" id="usuarioU">
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnActualizaUsuario" type="button" class="btn btn-warning" data-dismiss="modal">Actualiza Usuario</button>

					</div>
				</div>
			</div>
		</div>
         -->

        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="
https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>

<script src="js/traducciones.js"></script>
<script src="js/formulario_jquey.js"></script>
<link rel="stylesheet" href="css/estilos.css">

</body>
</html>

<script>    

    $(document).on('click', '#guardar', function(e){   
    	e.preventDefault();
    	var nombre = $('#nombre').val(),
        email = $('#email').val(),
        sexo = $('#sexo').val();
        area = $('#area').val();
        boletin = $('#boletin').val();
        descripcion = $('#descripcion').val();
        rol1 = $('#rol1').val();
        rol2 = $('#rol2').val();
        rol3 = $('#rol3').val();

        if(nombre!="" && email!="" && area!="" && descripcion!="")
        {
            $.ajax({
                url: '../controlador/insertarempleado.php', 
                method: 'POST',
                data: { nombre: nombre, email: email, sexo: sexo, area:area, boletin:boletin, descripcion:descripcion, rol1:rol1, rol2:rol2, rol3:rol3},
                success: function(r){
                    if (r='1') { 
                        $("#frmempleado")[0].reset();
                        swal("Información guardada con exito",  "", "success");																
                    } else {
                        swal("¡No se pudo guardar la información!", "", "success");																
                    }
                }
            });

         }
    });
    
  </script>

<script>
    function tiempoReal()
	{
		var tabla = $.ajax({
		url:'tablaempleado.php',
		dataType:'text',
		async:false
		}).responseText;
		document.getElementById("tablaUsuariosLoad").innerHTML = tabla;
	}
	setInterval(tiempoReal, 1000);
</script>