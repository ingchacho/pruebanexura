$.validator.addMethod('exp', function(value, element, param) 
{
  return this.optional(element) || value.match(param);
},'Solo acepta letras y espacios en blanco');



$("#frmempleado").validate({
    rules:{
        
        nombre:{
            required: true,
            minlength: 3,
            maxlength: 100,
            exp: /^[a-zA-ZÀ-ÿ\s]{1,40}$/ // Letras y espacios, pueden llevar acentos.
            //regexp: /^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ]+$/ /*Se escribe la expresión que vamos a usar*/
        },
        email:{
            required: true,
            email: true         
        },
         area:{
            required: true          
        },
        descripcion:{
            required: true,
            minlength: 5,
            maxlength: 200

        }
    }
})

$("#guardar").click(function(){

    if($("#frmempleado").valid()==false){
        return;
    }
    let nombre = $("#nombre").val()
    let email = $("#email").val()
    let sexo = $("#sexo").val()
    let area = $("#area").val()
    let descripcion = $("#descripcion").val()
    let boletin = $("#boletin").val()
    let rol1 = $("#rol1").val()
    let rol2 = $("#rol2").val()
    let rol3 = $("#rol3").val()    
});


