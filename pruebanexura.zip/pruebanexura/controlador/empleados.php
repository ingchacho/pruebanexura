<?php 
	class empleados{		

        public function obtenerdatosempleado($idempleado){
			$c=new conectar();
			$conexion=$c->conexion();
			$sql="SELECT id, nombre, email, sexo, area_id, descripcion from empleados where id='$idempleado'";
			$result=mysqli_query($conexion,$sql);
			$ver=mysqli_fetch_row($result);
			$datos=array(
						'id' => $ver[0],
							'nombre' => $ver[1],
							'email' => $ver[2],
							'sexo' => $ver[3],
							'area_id' => $ver[4],
							'descripcion' => $ver[5]
						);
			return $datos;
		}

		public function actualizaempleado($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE empleados set nombre='$datos[1]',
									email='$datos[2]',
									sexo='$datos[3]',
									area_id='$datos[4]',
									descripcion='$datos[5]'
						where id='$datos[0]'";
			return mysqli_query($conexion,$sql);	
		}

        public function eliminaempleado($idempleado){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="DELETE from empleados 
					where id='$idempleado'";
			return mysqli_query($conexion,$sql);
		}
    }

?>