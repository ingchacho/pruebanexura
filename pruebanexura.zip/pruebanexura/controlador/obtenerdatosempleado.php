<?php 
	require_once "Conexion.php";
	require_once "empleados.php";
	$obj= new usuarios;
	echo json_encode($obj->obtenerdatosempleado($_POST['idempleado']));
 ?>