<?php 
	require_once "Conexion.php";
	require_once "empleados.php";
	$obj= new empleados;
	echo json_encode($obj->obtenerdatosempleado($_POST['idempleado']));
 ?>