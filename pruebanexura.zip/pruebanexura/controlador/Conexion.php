<?php 
	class conectar{
		private $servidor="localhost";
		private $usuario="root";
		private $password="";
		private $bd="pruebanexura";

		public function conexion(){
			$mysqli=mysqli_connect($this->servidor,
									 $this->usuario,
									 $this->password,
									 $this->bd);
			return $mysqli;
		}
	}
 ?>