<?php 
	require_once "Conexion.php";
	require_once "empleados.php";
	$obj= new empleados;
	$datos=array(
			$_POST['idempleado'],  
		    $_POST['nombreU'], 
		    $_POST['emailU'],  
		    $_POST['sexoU'],
            $_POST['areaU'],
		    $_POST['descripcionU']
				);  
	echo $obj->actualizaempleado($datos);
 ?>