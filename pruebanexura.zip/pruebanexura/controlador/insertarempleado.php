<?php 
    require_once "../controlador/Conexion.php";
	$obj= new conectar();
	$mysqli= $obj->conexion();

    $nombre=$_POST['nombre'];
	$email=$_POST['email'];
	$sexo=$_POST['sexo'];
	$area=$_POST['area'];
	$boletin=$_POST['boletin'];
    $descripcion=$_POST['descripcion'];
    $rol1=$_POST['rol1'];
    $rol2=$_POST['rol2'];
    $rol3=$_POST['rol3'];

    $sql="INSERT into  empleados (nombre, 
    email, 
    sexo, 
    area_id,  
    boletin, 
    descripcion)
    value('$nombre', 
    '$email', 
    '$sexo', 
    '$area',  
    '$boletin', 
    '$descripcion')";
	$resultado = mysqli_query($mysqli, $sql);
	if(!$resultado)
		{
			echo"Error";
		}
    else
		{															
            $consulta= "SELECT id FROM empleados WHERE email='$email'";	
            if ($result = mysqli_query($mysqli, $consulta)) 
                {		
                    while ($fila = $result->fetch_row()) 
                    {
                        $idempleado =$fila[0];					                        
                    }			
                }

            $c="INSERT into  empleados_rol (empleado_id, rol_id) value('$idempleado', '$rol1')";
            $resultado = mysqli_query($mysqli, $c);
        }
?>
