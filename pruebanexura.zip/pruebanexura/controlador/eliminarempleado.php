<?php 
	require_once "Conexion.php";
	require_once "empleados.php";
	$obj= new empleados;
	echo $obj->eliminaempleado($_POST['idempleado']);
 ?>