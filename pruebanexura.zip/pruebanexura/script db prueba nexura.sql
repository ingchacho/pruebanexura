CREATE DATABASE pruebanextura;

create table areas(
	id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	nombre varchar(255) NOT NULL
);

create table empleado_rol(
	empleado_id int(11) NOT NULL,
	rol_id int(11) NOT NULL
);


create table empleados(
	id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	nombre varchar(255) NOT NULL,
	email varchar(255) NOT NULL,
	sexo char(1) NOT NULL,
	area_id int(11) NOT NULL,
	boletin int(11) NOT NULL,
	descripcion text NOT NULL,
	FOREIGN KEY (area_id) REFERENCES areas(id)
);

create table roles(
	id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	nombre varchar(255) NOT NULL
);

